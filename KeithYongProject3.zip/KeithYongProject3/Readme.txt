Keith Yong Project 3 readme

I got the threading and pipelining done and also added delay slots for lda, add, and subtract. The only thing I have not implemented are branching hazards because I started working on this project later than I hoped for. Also, run button does not work.